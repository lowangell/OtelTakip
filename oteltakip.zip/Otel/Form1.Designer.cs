﻿namespace Otel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            txtPhone = new TextBox();
            txtTC = new TextBox();
            txtRoomNumber = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            dtpGırıs = new DateTimePicker();
            label6 = new Label();
            btnSave = new Button();
            btnMusteriForm = new Button();
            label7 = new Label();
            dtpCikis = new DateTimePicker();
            txtTotalPrice = new TextBox();
            label8 = new Label();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            button3 = new Button();
            txtWidth = new TextBox();
            txtHeight = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            groupBox1 = new GroupBox();
            button1 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtFirstName
            // 
            txtFirstName.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtFirstName.Location = new Point(198, 40);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(245, 34);
            txtFirstName.TabIndex = 0;
            // 
            // txtLastName
            // 
            txtLastName.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtLastName.Location = new Point(198, 120);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(245, 34);
            txtLastName.TabIndex = 1;
            // 
            // txtPhone
            // 
            txtPhone.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtPhone.Location = new Point(198, 254);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(245, 34);
            txtPhone.TabIndex = 2;
            // 
            // txtTC
            // 
            txtTC.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtTC.Location = new Point(198, 184);
            txtTC.Name = "txtTC";
            txtTC.Size = new Size(245, 34);
            txtTC.TabIndex = 2;
            // 
            // txtRoomNumber
            // 
            txtRoomNumber.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtRoomNumber.Location = new Point(198, 330);
            txtRoomNumber.Name = "txtRoomNumber";
            txtRoomNumber.Size = new Size(245, 34);
            txtRoomNumber.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Pink;
            label1.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label1.ForeColor = Color.MidnightBlue;
            label1.Location = new Point(52, 49);
            label1.Name = "label1";
            label1.Size = new Size(46, 31);
            label1.TabIndex = 4;
            label1.Text = "Ad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Pink;
            label2.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label2.ForeColor = Color.MidnightBlue;
            label2.Location = new Point(52, 119);
            label2.Name = "label2";
            label2.Size = new Size(79, 31);
            label2.TabIndex = 5;
            label2.Text = "Soyad";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Pink;
            label3.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label3.ForeColor = Color.MidnightBlue;
            label3.Location = new Point(52, 253);
            label3.Name = "label3";
            label3.Size = new Size(134, 31);
            label3.TabIndex = 6;
            label3.Text = "Telefon No";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Pink;
            label4.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label4.ForeColor = Color.MidnightBlue;
            label4.Location = new Point(52, 183);
            label4.Name = "label4";
            label4.Size = new Size(53, 31);
            label4.TabIndex = 7;
            label4.Text = "T.C";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Pink;
            label5.Font = new Font("Sylfaen", 12F, FontStyle.Bold);
            label5.ForeColor = Color.MidnightBlue;
            label5.Location = new Point(61, 329);
            label5.Name = "label5";
            label5.Size = new Size(97, 31);
            label5.TabIndex = 8;
            label5.Text = "Oda No";
            // 
            // dtpGırıs
            // 
            dtpGırıs.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            dtpGırıs.Location = new Point(694, 71);
            dtpGırıs.Name = "dtpGırıs";
            dtpGırıs.Size = new Size(300, 34);
            dtpGırıs.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Pink;
            label6.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label6.Location = new Point(554, 74);
            label6.Name = "label6";
            label6.Size = new Size(124, 26);
            label6.TabIndex = 11;
            label6.Text = "Giris Tarihi";
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.GreenYellow;
            btnSave.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            btnSave.ForeColor = Color.DeepPink;
            btnSave.Location = new Point(20, 593);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(220, 119);
            btnSave.TabIndex = 13;
            btnSave.Text = "Kaydet";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click_1;
            // 
            // btnMusteriForm
            // 
            btnMusteriForm.BackColor = Color.Cyan;
            btnMusteriForm.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            btnMusteriForm.ForeColor = Color.DeepPink;
            btnMusteriForm.Location = new Point(271, 593);
            btnMusteriForm.Name = "btnMusteriForm";
            btnMusteriForm.Size = new Size(220, 119);
            btnMusteriForm.TabIndex = 14;
            btnMusteriForm.Text = "Müşterileri Gör";
            btnMusteriForm.UseVisualStyleBackColor = false;
            btnMusteriForm.Click += btnMusteriForm_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Pink;
            label7.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label7.Location = new Point(554, 135);
            label7.Name = "label7";
            label7.Size = new Size(126, 26);
            label7.TabIndex = 16;
            label7.Text = "Çıkış Tarihi";
            // 
            // dtpCikis
            // 
            dtpCikis.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            dtpCikis.Location = new Point(694, 132);
            dtpCikis.Name = "dtpCikis";
            dtpCikis.Size = new Size(300, 34);
            dtpCikis.TabIndex = 15;
            // 
            // txtTotalPrice
            // 
            txtTotalPrice.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtTotalPrice.Location = new Point(694, 223);
            txtTotalPrice.Name = "txtTotalPrice";
            txtTotalPrice.Size = new Size(300, 34);
            txtTotalPrice.TabIndex = 18;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Pink;
            label8.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label8.Location = new Point(534, 226);
            label8.Name = "label8";
            label8.Size = new Size(153, 26);
            label8.TabIndex = 19;
            label8.Text = "Tahmini Ücret";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(103, 34);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(223, 205);
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.GreenYellow;
            button2.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button2.ForeColor = Color.DeepPink;
            button2.Location = new Point(161, 261);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 23;
            button2.Text = "Fotoğraf";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.GreenYellow;
            button3.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button3.ForeColor = Color.DeepPink;
            button3.Location = new Point(161, 611);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 24;
            button3.Text = "Ayar";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // txtWidth
            // 
            txtWidth.ForeColor = Color.DeepPink;
            txtWidth.Location = new Point(321, 552);
            txtWidth.Name = "txtWidth";
            txtWidth.Size = new Size(48, 34);
            txtWidth.TabIndex = 25;
            // 
            // txtHeight
            // 
            txtHeight.BackColor = Color.White;
            txtHeight.ForeColor = Color.DeepPink;
            txtHeight.Location = new Point(144, 550);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(48, 34);
            txtHeight.TabIndex = 26;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Pink;
            label10.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label10.ForeColor = Color.DeepPink;
            label10.Location = new Point(43, 553);
            label10.Name = "label10";
            label10.Size = new Size(95, 26);
            label10.TabIndex = 28;
            label10.Text = "Uzunluk";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Pink;
            label11.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label11.ForeColor = Color.DeepPink;
            label11.Location = new Point(224, 555);
            label11.Name = "label11";
            label11.Size = new Size(91, 26);
            label11.TabIndex = 27;
            label11.Text = "Genişlik";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Pink;
            label12.Font = new Font("Sylfaen", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.DeepPink;
            label12.Location = new Point(113, 500);
            label12.Name = "label12";
            label12.Size = new Size(202, 31);
            label12.TabIndex = 29;
            label12.Text = "Fotoğraf Ayarları";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(txtHeight);
            groupBox1.Controls.Add(txtWidth);
            groupBox1.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            groupBox1.Location = new Point(1105, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(417, 688);
            groupBox1.TabIndex = 30;
            groupBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.LavenderBlush;
            button1.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button1.ForeColor = Color.DeepPink;
            button1.Location = new Point(534, 593);
            button1.Name = "button1";
            button1.Size = new Size(220, 119);
            button1.TabIndex = 31;
            button1.Text = "Çıkış";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.DeepSkyBlue;
            button4.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button4.ForeColor = Color.DeepPink;
            button4.Location = new Point(790, 593);
            button4.Name = "button4";
            button4.Size = new Size(220, 119);
            button4.TabIndex = 32;
            button4.Text = "Arşiv";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCoral;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1635, 717);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Controls.Add(label8);
            Controls.Add(txtTotalPrice);
            Controls.Add(label7);
            Controls.Add(dtpCikis);
            Controls.Add(btnMusteriForm);
            Controls.Add(btnSave);
            Controls.Add(label6);
            Controls.Add(dtpGırıs);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtRoomNumber);
            Controls.Add(txtTC);
            Controls.Add(txtPhone);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            ForeColor = Color.MidnightBlue;
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFirstName;
        private TextBox txtLastName;
        private TextBox txtPhone;
        private TextBox txtTC;
        private TextBox txtRoomNumber;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private DateTimePicker dtpGırıs;
        private Label label6;
        private Button btnSave;
        private Button btnMusteriForm;
        private Label label7;
        private DateTimePicker dtpCikis;
        private TextBox txtTotalPrice;
        private Label label8;
        private Label label9;
        private PictureBox pictureBox1;
        private Button button2;
        private Button button3;
        private TextBox txtWidth;
        private TextBox txtHeight;
        private Label label10;
        private Label label11;
        private Label label12;
        private GroupBox groupBox1;
        private Button button1;
        private Button button4;
    }
}
