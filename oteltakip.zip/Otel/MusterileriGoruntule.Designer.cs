﻿namespace Otel
{
    partial class MusterileriGoruntule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnDelete = new Button();
            btnGeriDon = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label5 = new Label();
            txtTC = new TextBox();
            txtPhone = new TextBox();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            ücret = new Label();
            txtTotalPrice = new TextBox();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.Pink;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.Pink;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1305, 223);
            dataGridView1.TabIndex = 0;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Cyan;
            btnDelete.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            btnDelete.ForeColor = Color.DeepPink;
            btnDelete.Location = new Point(847, 374);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(178, 150);
            btnDelete.TabIndex = 1;
            btnDelete.Text = "Sil";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click_1;
            // 
            // btnGeriDon
            // 
            btnGeriDon.BackColor = Color.Pink;
            btnGeriDon.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            btnGeriDon.ForeColor = Color.DeepPink;
            btnGeriDon.Location = new Point(1452, 530);
            btnGeriDon.Name = "btnGeriDon";
            btnGeriDon.Size = new Size(178, 150);
            btnGeriDon.TabIndex = 2;
            btnGeriDon.Text = "Ana Sayfa";
            btnGeriDon.UseVisualStyleBackColor = false;
            btnGeriDon.Click += btnGeriDon_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.GreenYellow;
            button1.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button1.ForeColor = Color.DeepPink;
            button1.Location = new Point(542, 374);
            button1.Name = "button1";
            button1.Size = new Size(178, 150);
            button1.TabIndex = 4;
            button1.Text = "Güncelle";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Pink;
            label4.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label4.ForeColor = Color.MidnightBlue;
            label4.Location = new Point(102, 549);
            label4.Name = "label4";
            label4.Size = new Size(78, 26);
            label4.TabIndex = 16;
            label4.Text = "T.C No\r\n";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Pink;
            label3.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label3.ForeColor = Color.MidnightBlue;
            label3.Location = new Point(94, 469);
            label3.Name = "label3";
            label3.Size = new Size(116, 26);
            label3.TabIndex = 15;
            label3.Text = "Telefon No";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Pink;
            label2.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label2.ForeColor = Color.MidnightBlue;
            label2.Location = new Point(102, 404);
            label2.Name = "label2";
            label2.Size = new Size(68, 26);
            label2.TabIndex = 14;
            label2.Text = "Soyad";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Pink;
            label5.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            label5.ForeColor = Color.MidnightBlue;
            label5.Location = new Point(102, 327);
            label5.Name = "label5";
            label5.Size = new Size(39, 26);
            label5.TabIndex = 13;
            label5.Text = "Ad";
            // 
            // txtTC
            // 
            txtTC.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtTC.ForeColor = Color.MidnightBlue;
            txtTC.Location = new Point(216, 543);
            txtTC.Name = "txtTC";
            txtTC.Size = new Size(150, 34);
            txtTC.TabIndex = 12;
            // 
            // txtPhone
            // 
            txtPhone.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtPhone.ForeColor = Color.MidnightBlue;
            txtPhone.Location = new Point(216, 466);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(150, 34);
            txtPhone.TabIndex = 11;
            // 
            // txtLastName
            // 
            txtLastName.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtLastName.ForeColor = Color.MidnightBlue;
            txtLastName.Location = new Point(216, 401);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(150, 34);
            txtLastName.TabIndex = 10;
            // 
            // txtFirstName
            // 
            txtFirstName.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtFirstName.ForeColor = Color.MidnightBlue;
            txtFirstName.Location = new Point(216, 327);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(150, 34);
            txtFirstName.TabIndex = 9;
            // 
            // ücret
            // 
            ücret.AutoSize = true;
            ücret.BackColor = Color.Pink;
            ücret.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            ücret.ForeColor = Color.MidnightBlue;
            ücret.Location = new Point(102, 611);
            ücret.Name = "ücret";
            ücret.Size = new Size(64, 26);
            ücret.TabIndex = 18;
            ücret.Text = "Ücret";
            // 
            // txtTotalPrice
            // 
            txtTotalPrice.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            txtTotalPrice.ForeColor = Color.MidnightBlue;
            txtTotalPrice.Location = new Point(216, 605);
            txtTotalPrice.Name = "txtTotalPrice";
            txtTotalPrice.Size = new Size(150, 34);
            txtTotalPrice.TabIndex = 17;
            // 
            // button2
            // 
            button2.BackColor = Color.Cyan;
            button2.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button2.ForeColor = Color.DeepPink;
            button2.Location = new Point(1252, 530);
            button2.Name = "button2";
            button2.Size = new Size(178, 150);
            button2.TabIndex = 19;
            button2.Text = "Çıkış";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // MusterileriGoruntule
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCoral;
            BackgroundImage = Properties.Resources.japan_cherry_blossom_rbofhm6ztuoe9ti5;
            ClientSize = new Size(1669, 698);
            Controls.Add(button2);
            Controls.Add(ücret);
            Controls.Add(txtTotalPrice);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label5);
            Controls.Add(txtTC);
            Controls.Add(txtPhone);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(button1);
            Controls.Add(btnGeriDon);
            Controls.Add(btnDelete);
            Controls.Add(dataGridView1);
            ForeColor = SystemColors.Window;
            Name = "MusterileriGoruntule";
            Text = "MusterileriGoruntule";
            Load += MusterileriGoruntule_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnDelete;
        private Button btnGeriDon;
        private Button button1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label5;
        private TextBox txtTC;
        private TextBox txtPhone;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private Label ücret;
        private TextBox txtTotalPrice;
        private Button button2;
    }
}