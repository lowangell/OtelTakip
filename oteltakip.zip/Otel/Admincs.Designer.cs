﻿namespace Otel
{
    partial class Admincs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            timer = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.GreenYellow;
            button1.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button1.ForeColor = Color.DeepPink;
            button1.Location = new Point(675, 421);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "Giriş";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            textBox1.Location = new Point(428, 263);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(236, 34);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sylfaen", 12F, FontStyle.Bold | FontStyle.Underline);
            label1.ForeColor = Color.DeepPink;
            label1.Location = new Point(265, 266);
            label1.Name = "label1";
            label1.Size = new Size(157, 31);
            label1.TabIndex = 2;
            label1.Text = "Kullanıcı Adı";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Sylfaen", 12F, FontStyle.Bold | FontStyle.Underline);
            label2.ForeColor = Color.DeepPink;
            label2.Location = new Point(265, 352);
            label2.Name = "label2";
            label2.Size = new Size(65, 31);
            label2.TabIndex = 4;
            label2.Text = "Şifre";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            textBox2.Location = new Point(428, 349);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(236, 34);
            textBox2.TabIndex = 3;
            // 
            // button2
            // 
            button2.BackColor = Color.GreenYellow;
            button2.Font = new Font("Sylfaen", 10F, FontStyle.Bold);
            button2.ForeColor = Color.DeepPink;
            button2.Location = new Point(835, 421);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 5;
            button2.Text = "Kayıt Ol";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Location = new Point(43, 629);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(244, 148);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // Admincs
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCoral;
            BackgroundImage = Properties.Resources._2159510;
            ClientSize = new Size(1683, 818);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(button1);
            ForeColor = Color.MidnightBlue;
            Name = "Admincs";
            Text = "Admincs";
            Load += Admincs_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private Button button2;
        private PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer;
    }
}