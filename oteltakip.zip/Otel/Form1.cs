using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Drawing;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace Otel
{
    public partial class Form1 : Form
    {
        private List<string> odaNumaralari = new List<string>();
        public Form1()
        {
            InitializeComponent();
            LoadRoomNumbers();
        }
        private void LoadRoomNumbers()
        {
            string conn = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection conn2 = new SqlConnection(conn);
            string query = "SELECT RoomNumber FROM Customers";
            SqlCommand cmd = new SqlCommand(query, conn2);

            conn2.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                odaNumaralari.Add(reader["RoomNumber"].ToString());
            }
            conn2.Close();
        }



        private void btnMusteriForm_Click_1(object sender, EventArgs e)
        {
            MusterileriGoruntule musterileriGoruntule = new MusterileriGoruntule();
            musterileriGoruntule.Show();
            this.Hide();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            if (txtTC.Text.Length != 11 || txtPhone.Text.Length != 10)
            {
                MessageBox.Show("Tc Kimlik numarasi 11 haneli, telefon numarasi da 10 haneli olmalidir lutfen tekrar giris yapiniz!!!");
                return;
            }
            DateTime checkInDate = dtpGırıs.Value;
            DateTime checkOutDate = dtpCikis.Value;
            if (checkOutDate <= checkInDate)
            {
                MessageBox.Show("Çıkış tarihi, giriş tarihinden daha sonraki bir tarih olmalıdır!", "Tarih Hatası", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (odaNumaralari.Contains(txtRoomNumber.Text))
            {
                MessageBox.Show("Bu oda numarası zaten dolu. Lütfen başka bir oda numarası giriniz.");
                return;
            }


            if (odaNumaralari.Count >= 100)
            {
                MessageBox.Show("Maksimum oda kapasitesine ulaşıldı. 100'den fazla oda numarası eklenemez.");
                return;
            }


            odaNumaralari.Add(txtRoomNumber.Text);

            string conn = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";

            SqlConnection conn2 = new SqlConnection(conn);
            string query = "INSERT INTO Customers (FirstName,LastName,Phone,TC,RoomNumber,CheckInDate,CheckOutDate,TotalPrice) VALUES (@firstname,@lastname,@tc,@phone,@room,@indate,@outdate,@totalprice)";
            SqlCommand cmd = new SqlCommand(query, conn2);
            cmd.Parameters.AddWithValue("@firstname", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@lastname", txtLastName.Text);
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@tc", txtTC.Text);
            cmd.Parameters.AddWithValue("@room", txtRoomNumber.Text);
            cmd.Parameters.AddWithValue("@indate", dtpGırıs.Value);
            cmd.Parameters.AddWithValue("@outdate", dtpCikis.Value);
            cmd.Parameters.AddWithValue("@totalprice", txtTotalPrice.Text);
            conn2.Open();
            cmd.ExecuteNonQuery();
            conn2.Close();

            MessageBox.Show("Musteri basariyla girildi");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string imagePath = @"D:\C#OrnekUygulama\Otel\Otel\Resources\pp.jpg.jpg";

            if (File.Exists(imagePath))
            {

                pictureBox1.Image = Image.FromFile(imagePath);
                MessageBox.Show("Resim başarıyla yüklendi!");
            }
            else
            {
                MessageBox.Show("Resim dosyası bulunamadı. Lütfen yolu kontrol edin.");
            }
        }
        private Image ResizeImage(Image originalImage, int width, int height)
        {
            Bitmap resizedImage = new Bitmap(width, height);
            using (Graphics graphics = Graphics.FromImage(resizedImage))
            {

                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.DrawImage(originalImage, 0, 0, width, height);
            }
            return resizedImage;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                try
                {

                    int newWidth = int.Parse(txtWidth.Text);
                    int newHeight = int.Parse(txtHeight.Text);


                    Image resizedImage = ResizeImage(pictureBox1.Image, newWidth, newHeight);


                    pictureBox1.Image = resizedImage;
                    MessageBox.Show("Resim başarıyla yeniden boyutlandırıldı!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Bir hata oluştu: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Lütfen önce bir resim yükleyin.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admincs admincs = new Admincs();
            admincs.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Arsiv arsiv = new Arsiv();
            arsiv.Show();
            this.Close();
        }
    }
}
