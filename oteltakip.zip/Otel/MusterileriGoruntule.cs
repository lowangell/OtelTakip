﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel
{
    public partial class MusterileriGoruntule : Form
    {
        public MusterileriGoruntule()
        {
            InitializeComponent();
        }

        private void MusterileriGoruntule_Load(object sender, EventArgs e)
        {
            LoadCustomers();
        }
        private void LoadCustomers()
        {
            string conn = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";
            SqlConnection conn2 = new SqlConnection(conn);
            string query = "SELECT * FROM Customers";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn2);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {



            if (dataGridView1.SelectedRows.Count > 0)
            {
                int customerID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["CustomerID"].Value);
                string connString = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";
                SqlConnection conn2 = new SqlConnection(connString);


                string query = "SELECT CheckInDate, CheckOutDate FROM Customers WHERE CustomerID = @customerID";
                SqlCommand cmd = new SqlCommand(query, conn2);
                cmd.Parameters.AddWithValue("@customerID", customerID);

                try
                {
                    conn2.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        DateTime checkInDate = reader.GetDateTime(0);
                        DateTime checkOutDate = reader.GetDateTime(1);


                        int daysStayed = 0;
                        daysStayed = (checkOutDate - checkInDate).Days;

                        decimal totalPrice = daysStayed * 1000 + 1000;




                        MessageBox.Show($"Toplam Ücret: {totalPrice:C}", "Müşteri Silindi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Müşteri bilgileri bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hata: {ex.Message}", "Veritabanı Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn2.Close();
                }


                string deleteQuery = "DELETE FROM Customers WHERE CustomerID = @customerID";
                SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn2);
                deleteCmd.Parameters.AddWithValue("@customerID", customerID);

                try
                {
                    conn2.Open();
                    deleteCmd.ExecuteNonQuery();
                    MessageBox.Show("Müşteri başarıyla silindi.");
                    LoadCustomers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Silme işlemi sırasında hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn2.Close();
                }
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir müşteri seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }





        private void btnGeriDon_Click_1(object sender, EventArgs e)
        {
            Form1 anasayfa = new Form1();
            anasayfa.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
          string.IsNullOrWhiteSpace(txtLastName.Text) ||
          string.IsNullOrWhiteSpace(txtPhone.Text) ||
          string.IsNullOrWhiteSpace(txtTC.Text))
            {
                MessageBox.Show("Tüm alanları doldurun.");
                return;
            }
            if (txtPhone.Text.Length != 10 || !long.TryParse(txtPhone.Text, out _))
            {
                MessageBox.Show("Telefon numarasi 10 haneli olmalidir!!");
                return;
            }


            if (dataGridView1.SelectedRows.Count == 1)
            {
                int customerID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["CustomerID"].Value);


                string conn = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";
                SqlConnection conn2 = new SqlConnection(conn);
                string query = "UPDATE Customers SET FirstName = @name, LastName = @lastname, Phone = @phone, TotalPrice = @totalprice WHERE CustomerID = @customerID";

                SqlCommand cmd = new SqlCommand(query, conn2);
                cmd.Parameters.AddWithValue("@name", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@lastname", txtLastName.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@customerID", customerID);
                cmd.Parameters.AddWithValue("@totalprice", txtTotalPrice.Text);

                try
                {
                    conn2.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Müşteri bilgileri başarıyla güncellendi.");

                        LoadCustomers();
                    }
                    else
                    {
                        MessageBox.Show("Müşteri bulunamadı. Lütfen doğru TC Kimlik Numarasını girin.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message);
                }
                finally
                {
                    conn2.Close();
                }
            }
            else
            {
                MessageBox.Show("Lütfen güncellemek için bir müşteri seçin.");
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];


                txtTC.Text = row.Cells["TC"].Value.ToString();
                txtFirstName.Text = row.Cells["FirstName"].Value.ToString();
                txtLastName.Text = row.Cells["LastName"].Value.ToString();
                txtPhone.Text = row.Cells["Phone"].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admincs admincs = new Admincs();
            admincs.Show();
            this.Close();
        }

        
    }
}
