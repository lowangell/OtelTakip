﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel
{
    public partial class Admincs : Form
    {
        public Admincs()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;


            Admin admin = new AdminI
            {
                Username = username,
                Password = password
            };


            AdminKontrol adminRepo = new AdminKontrol();
            bool isValid = adminRepo.ValidateAdmin(admin);

            if (isValid)
            {
                MessageBox.Show("Giriş Başarılı!");


                Form1 adminPanel = new Form1();
                adminPanel.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre yanlış!");
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            AdminKayit adminKayit = new AdminKayit();
            adminKayit.Show();

        }

        private void Admincs_Load(object sender, EventArgs e)
        {
            string gifPath = @"D:\C#OrnekUygulama\Otel\Otel\Resources\hello-hi.gif";
            if (System.IO.File.Exists(gifPath))
            {
                pictureBox1.Image = Image.FromFile(gifPath);
            }
            else
            {
                MessageBox.Show("GIF dosyası bulunamadı. Lütfen yolu kontrol edin.");
                return;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Kullanıcı Koşullarını Kabul ettiniz!!!");
        }
    }
}

