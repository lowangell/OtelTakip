﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Otel
{
    public class AdminKontrol
    {
        private string connString = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";

        
        public bool ValidateAdmin(Admin admin)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT COUNT(1) FROM Admins WHERE Username = @username AND Password = @password";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", admin.Username);
                cmd.Parameters.AddWithValue("@password", admin.Password);
                conn.Open();

                int result = Convert.ToInt32(cmd.ExecuteScalar());
                return result == 1; 
            }
        }
    }
}
