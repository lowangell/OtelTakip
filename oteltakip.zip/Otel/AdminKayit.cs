﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel
{
    public partial class AdminKayit : Form
    {
        public AdminKayit()
        {
            InitializeComponent();
            button1.Enabled = false;

            string[] cinsiyetler = { "Kadin", "Erkek", "Diger" };
            for (int i = 0; i < cinsiyetler.Length; i++)
            {
                comboBox1.Items.Add(cinsiyetler[i]);
            }
            comboBox1.Text = "Cinsiyet Seciniz";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            string cinsiyet = comboBox1.Text;
            string confirmPassword = textBox3.Text;


            if (password != confirmPassword)
            {
                MessageBox.Show("Şifreler uyuşmuyor. Lütfen tekrar deneyin.");
                return;
            }


            string connString = @"Data Source=SilaLegion\SQLEXPRESS;Initial Catalog=OTEL;Integrated Security=True;Trust Server Certificate=True";
            string query = "INSERT INTO Admins (Username, Password, Cinsiyet) VALUES (@username, @password, @cinsiyet)";

            using (SqlConnection conn = new SqlConnection(connString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@cinsiyet", cinsiyet);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Admin başarıyla kaydedildi!");


                    Admincs loginForm = new Admincs();
                    loginForm.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message);
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            button1.Enabled = checkBox1.Checked;
        }
    }
}
    
